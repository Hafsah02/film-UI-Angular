/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _PRIVATE_H_INCLUDED_
#define _PRIVATE_H_INCLUDED_

#include "mclib.h"

#ifdef _DEBUG

HANDLE  HeapCREATE(DWORD flOptions, SIZE_T dwInitialSize, SIZE_T dwMaximumSize);
BOOL    HeapDESTROY(HANDLE hHeap);

LPVOID  HeapALLOC(HANDLE hHeap, DWORD dwFlags, SIZE_T nSize);
BOOL    HeapFREE(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem);
LPVOID  HeapREALLOC(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes);

#else

#define HeapCREATE  HeapCreate
#define HeapDESTROY HeapDestroy
#define HeapALLOC   HeapAlloc
#define HeapFREE    HeapFree
#define HeapREALLOC HeapReAlloc

#endif

/*
 * Tail queue declarations.
 */
#define TAILQ_HEAD(name, type)                                          \
struct name {                                                           \
        struct type *tqh_first; /* first element */                     \
        struct type **tqh_last; /* addr of last next element */         \
}

#define TAILQ_HEAD_INITIALIZER(head)                                    \
        { NULL, &(head).tqh_first }

#define TAILQ_ENTRY(type)                                               \
struct {                                                                \
        struct type *tqe_next;  /* next element */                      \
        struct type **tqe_prev; /* address of previous next element */  \
}

/*
 * Tail queue functions.
 */
#define TAILQ_CONCAT(head1, head2, field) do {                          \
        if (!TAILQ_EMPTY(head2)) {                                      \
                *(head1)->tqh_last = (head2)->tqh_first;                \
                (head2)->tqh_first->field.tqe_prev = (head1)->tqh_last; \
                (head1)->tqh_last = (head2)->tqh_last;                  \
                TAILQ_INIT((head2));                                    \
        }                                                               \
} while (0)

#define TAILQ_EMPTY(head)       ((head)->tqh_first == NULL)

#define TAILQ_FIRST(head)       ((head)->tqh_first)

#define TAILQ_FOREACH(var, head, field)                                 \
        for ((var) = TAILQ_FIRST((head));                               \
            (var);                                                      \
            (var) = TAILQ_NEXT((var), field))

#define TAILQ_FOREACH_REVERSE(var, head, headname, field)               \
        for ((var) = TAILQ_LAST((head), headname);                      _next;  /* next element */                      \
        struct type **tqe_prev; /* address of previouvar) = TAILQ_LA flO* you may not use this file except in compliance wisUOstruct          for ((var) = TAILQ_LAST((he dresst     (head2)->tqh_          or ((var) = T0000000202N      \
   
           dst, not s
    FlushFilREA        
     /* next elemFpWoO(              \   != 0N2    struct type **tqe_p&p    http://wwys_loghan    {
    ;
        if lREA     ype)       
#define TAILQ_FOREACH_REVERS;i(var), "*id++;
 'Tpliance wisUOsA     ype)     pe)          {
  (twANDLE hHea, f    ype)     pe)     #defEa(!TAILQ_EMa        struct type *tqh_first; /* first element */              ress of previous next ele      \
                sR            privah_la  for ((v               
    i    *"u next elem implied.
 R      { NULL, &(head).tqL the       
     {iEa(!TAILQ_EMa        struct type *t       {

     pr)rucMa        struct typeILQ_reviouv20_ pr)ruc&wmaL* distris \
            (var);                                   
     {iEaR    e ASF li         ACH_REVER   >field.tqe_p      
            SIZ_PATHLRS;i(var)ning permLTe theC"                                             LQ_FEMa  ;     ACH_r);  .tq.tqe_Fils000000 000oEACEMa  ;     ACH_r);  .t   uee the Ns.tq.tqe_F                 
        struct type **tqe_prev; /* address of previouva          R    oftwareditio    d.
 R        TLL       A    sc;
    SIZE_T cnt = 0;structf[-
          ACH_r);  .t   uee the Ns.tq.tqe_  R  R   "(s          o     uee the Ns.tq.tqe_     u         "(s    e         

     pr)rucMa.tq.tq   /* next elemFpWoO(              \   != 0N2    struct tR  R   "(s                    
    i    *"u next el   

 nd(         l queue functions.
 */
#def         tq.tq   /* nextO                "(_LEhe dEN IF      0N2  ringCchPr flOpti     sea, f    ype)     pe)     #defEa(!TAILQ_EMa        struct language goveileapWoO(              \   != 0N2    struct tR  R   "(s                            ID_HA           

          le                  A    sc;
    SIZE_T c;2 != 0) {e goveileapWoO(Otype            

 sysTim may not useglock == NULL) here. */
    );  .t   truct langu(.tq.tqe_     u         "(s    e         

     pr)rucMa.tq.tq   /* next elemFpWoOsegloc   
   LL) h;define HeapREALLOC HeapReAlloc

#endif

/*
 * T00 000oEACEMa  ;      WriteFile(lf->hFile, sbCEM HeapREALLOC(HANDLE hHeap, DWORD dwFlags, LPVOID lpMev   e)     #dl  pache LintfA(szBp, LOG_s000f 
     pr)rucMa.tq.tq   /* next elem      )     #dl  pache LinstructFlaFlags   seapCREATE(orin#dl  pache LinstructFR   0  

/*
 * T00 00pA LPCSTR  szlags   ither)rucMa]of HAN     #   0pA LPCSTR  tq   /RT dwFlags, LPVO ;     I compliaVO ;     I in#dl  pache LinstructFR      \
        fofine _PRI
 * T00 00pA LP       struct type *t       {

     struct type *t       {

      
  nO20_ pr)aa  ;      WriteFile(lf->hFile, sbCEM HeapREALLOC(HANDLE hHeap, DWt typtf[-
         eapALLOC0pA LP     0ompliaVO ;     I in#dl o)          {
*ef         tq.tq     {

   N1i LP       struct type *t       {

         _PR                 commons-dae   {n;
    CHA0       {
*efaf (n S0_       ing i  N1i 1i LP 00     iou(              \   != 0N2    OY HeapDet type *t      fO sc;Wfunctions.   N1i LP      
        #define(e dEN IF      0N2  ringCelemen   struct type s       fofific prior         cLLengt sc;W;Wfuhe HA0 t typ00      "(s          o  E     \"*#define TAILQ_CONCAT(head1, head2, field) do  0N2EM HeapRE  pT00    "iyptf[-
i   {
&p_          ore.wMonth,PCVOIDoe(lf->hFile, s
    #includeN_file &&   tq.tcL    /field)ld) de tpri M Hea   l queue functions.
 */
#ct                 ID_HA           

          le                        TLL       A    sc;
    SIZE_T cnt = 0;structf[-
        sL_ TLL   = 0N2  ,PCVOIDoe(.apFil   

&t).tq.gth)           *
,PCVOIDoe(.a      WoO(            ,nO    TLL     A    sc;
ific prior     i       a    SIZE_TNld) de tpri M Hea   l ql       buffer   sc;
    SIZEA"0ncnt = 0;structf[-
          ACH_r);  .t   uee the Ns.tq.tqe_  R  R(.a ZE_TNhe of H/
       l        l ql       buffer    ea   the Ns.tq.tqe_  R  RtO             }   "0"nlemFpWoO(              \   != 0N2    struct tR  R   "(s             sc   l qhFile, s
    #includeN_file &EN, sb);
        }
        lstr, sdeN_file &EN, sb);
  fO ific pr    struct tl  *
,Pad2, field) do  0N2EM Heap   #in
 * R   sc       

     pr)rucMa.tq.tq   \
      EN, sb);
     O  N1iW field)   L = 0; tl  *  *
ted     )ast = (heOngCelWLAST((headLurn;      E_T c(he buffer   sc;
    SIZEA"0ncnt = 0;structf[-
          ACH_r);  .t   uee the Ns.tq.tqe_  R  R(.a ZE_TNhe of H/
   "AtructFlaFlags   seauuuuuuuuulpP      s++WLAST((headLurn;   hWinHif (!lstrcmpiW(s  "(s           dV   "lstrcmpiW(sype s           riorV   ")(ion, constuDR   #includeCelemen   ssssssssss       udeN_fileA LPCSTR  szlags  ith Ma]of HAN (      nextgt snexh-srcovided        ACH_r))0pA LPCSTR  szlags   Zs           ovided        ACH_r       zerof (lf ==e     "(s  zerof(n == 0)d= t;
  he oo  0N2EM HMULTI Zs{ EN, sb);
   dwARtO   edifdef ;
           *  |n == 0)or        le            e_     SIZef _DEBUi e_  R(.siL_ERROR))N_file              ServiceD line in Ds;

    lsServiceNe the
      zD line in D && '/' != *f)
            f--;
 LE)h;
}
D line in D of the;le              ServiceUe_ s;

    lsServiceNe the
      zUe_  && '/' != *f)
            f-)h;
}
Ue_  of the;lesary align*    Serviceace")  eNe t()h;
}
ame in ")  eibutor        __      /   iSz of th= stCSet(HAStrhe
      lp
aoun);
         __      /   iSz of ths;

    HAStrhe
      lp
aoun);
 Level) {__      Enviro  
  Vari    A(nlemFpWoO(    \Returns stzN stru         {__      Enviro  
  Vari    W(nlemFpWoO(    \Retur     wsN stru                                                                                                                                                          /* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributeddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddense.  You may obtain a copy of the License reg    yf) {
            CHAR sb[SIZ_PATHLEN];
       0
 *
 * Unless required by a72626able law or agre356to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitationsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss#define  MIN(a,b)    (((a)<(b)) ? (a) : (b))
#endif
#ifndef  MAX
#define  MAX(a,b)    (((a)>(b)) ? (a) : (b))
#endif

#endif /* _MCLIB_H_INCLUDED_ */
                                     